<?php
	/***************************************************************
	*  Copyright notice
	*
	*  (c) 2009 Frederik Mogensen, David Askirk <frede@server-1.dk, x1q@fdf.dk>
	*  All rights reserved
	*
	*  This script is part of the TYPO3 project. The TYPO3 project is
	*  free software; you can redistribute it and/or modify
	*  it under the terms of the GNU General Public License as published by
	*  the Free Software Foundation; either version 2 of the License, or
	*  (at your option) any later version.
	*
	*  The GNU General Public License can be found at
	*  http://www.gnu.org/copyleft/gpl.html.
	*
	*  This script is distributed in the hope that it will be useful,
	*  but WITHOUT ANY WARRANTY; without even the implied warranty of
	*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	*  GNU General Public License for more details.
	*
	*  This copyright notice MUST APPEAR in all copies of the script!
	***************************************************************/
	
	/**
	* Plugin 'Video Connection' for the 'videoconnection' extension.
	*
	* @author	Frederik Mogensen, David Askirk <frede@server-1.dk, x1q@fdf.dk>
	* 
	* Edited by Brian Hauge brian.hauge@gmail.com - For use in Pascal
	* 
	*/


require_once(PATH_tslib.'class.tslib_pibase.php');

class tx_videoconnection_pi1 extends tslib_pibase {
	var $prefixId = 'tx_videoconnection_pi1';						// Same as class name
	var $scriptRelPath = 'pi1/class.tx_videoconnection_pi1.php';	// Path to this script relative to the extension dir.
	var $extKey = 'videoconnection';								// The extension key.
	var $templateCode;
	var $rpp = 5;
	var $cpp = 2; // Comments pr page
	var $status = array();
	var $error = array();


		/**
		* The main method of the PlugIn
		*
		* @param	string		$content: The PlugIn content
		* @param	array		$conf: The PlugIn configuration
		* @return	The content that is displayed on the website
		*/
	function main($content,$conf)	{
		$this->conf=$conf;
		$this->pi_setPiVarDefaults();
		$this->pi_loadLL();
		$this->pi_USER_INT_obj=1; // Configuring so caching is not expected. This value means that no cHash params are ever set. We do this, because it's a USER_INT object!
		$this->pi_initPIflexForm();
		$this->piVars['pid'] = $this->conf['storagePid'];

		$piFlexForm = $this->cObj->data['pi_flexform'];
		$listFunction = intval($piFlexForm['data']['sDEF']['lDEF']['database_type']['vDEF']);
		$this->categoryFromFlex  = $piFlexForm['data']['sDEF']['lDEF']['category'];
		$this->simpleView = intval($piFlexForm['data']['sDEF']['lDEF']['simpleView']['vDEF']);
		$this->simpleVideoUID = intval($piFlexForm['data']['sDEF']['lDEF']['videoUID']['vDEF']);

		// Load template code
		$this->templateCode = $this->cObj->fileResource($this->conf['templateFile']);

		$key = $this->prefixId . '_' . md5($subPart);
		if (!isset($GLOBALS['TSFE']->additionalHeaderData[$key])) {
			$headerParts = $this->cObj->getSubpart($this->templateCode, '###HEADER_ADDITIONS###');
			if ($headerParts) {
				$headerParts = $this->cObj->substituteMarker($headerParts, '###SITE_REL_PATH###', t3lib_extMgm::siteRelPath('videoconnection'));
				$GLOBALS['TSFE']->additionalHeaderData[$key] = $headerParts;
			}
		}

		
		if ($listFunction == 4) {
			if ($GLOBALS['TSFE']->fe_user->user == false) {
				$content = '<p>' . $this->pi_getLL('user_not_logedin') .' </p>';
				return $this->pi_wrapInBaseClass($content);
			}
			
			
			if (isset($this->piVars['url'])) {
				if ($this->saveUserInputToDatabase()) {
					$content = 'Videoen er gemt...';
					$content .= $this->pi_linkTP_keepPIvars(htmlspecialchars($this->piVars['title']),
						array('movie'=>$this->movieId),
						0,
						0,
						$this->conf['singlePid'])
						.'<br>';
				} else {
					$content = $this->pi_getLL('error_saving_video');
					$content .= $this->submitFormBig($this->categoryFromFlex);
				}
			} else {
				$content = $this->submitFormBig($this->categoryFromFlex);
			}
			
		} else if ($listFunction == 5) {
			if ($GLOBALS['TSFE']->fe_user->user == false) {
				$content = '<p>' . $this->pi_getLL('user_not_logedin') .' </p>';
				return $this->pi_wrapInBaseClass($content);
			}
			
			if (isset($this->piVars['url'])) {
				if ($this->saveUserInputToDatabase()) {
					$content = 'Videoen er gemt...';
					$content .= $this->pi_linkTP_keepPIvars(htmlspecialchars($this->piVars['title']),
						array('movie'=>$this->movieId),
						0,
						0,
						$this->conf['singlePid'])
						.'<br>';
				} else {
					$content = $this->pi_getLL('error_saving_video');
					$content .= $this->submitFormSmall($this->categoryFromFlex);
				}
			} else {
				$content = $this->submitFormSmall($this->categoryFromFlex);
			}
		}  else if ($listFunction == 13) {
			if ($GLOBALS['TSFE']->fe_user->user == false) {
				$content = '<p>' . $this->pi_getLL('user_not_logedin') .' </p>';
				return $this->pi_wrapInBaseClass($content);
			}
			if (isset($this->piVars['title'])) {
				if ($this->saveUserInputToDatabaseVideoPictures()) {
					$content .= 'Billederne er gemt...';
					$content .= $this->pi_linkTP_keepPIvars(htmlspecialchars($this->piVars['title']),
						array('movie'=>$this->movieId),
						0,
						0,
						$this->conf['singlePid'])
						.'<br>';
				} else {
					$content = $this->pi_getLL('error_saving_video');
					$content .= $this->submitFormPictures();
				}
			} else {
				$content = "Skriv venligst en titel ind<br /><br />";
				$content .= $this->submitFormPictures();
			}
		}  else if ($listFunction == 16) {
			if ($GLOBALS['TSFE']->fe_user->user == false) {
				$content = '<p>' . $this->pi_getLL('user_not_logedin') .' </p>';
				return $this->pi_wrapInBaseClass($content);
			}
			if (isset($this->piVars['url'])) {
				if ($this->saveUserInputToDatabaseVideoPictures() && empty($this->error)) {
					$content .= 'Video og billeder er gemt... ';
					$content .= $this->pi_linkTP_keepPIvars(htmlspecialchars($this->piVars['title']),
						array('movie'=>$this->movieId),
						0,
						0,
						$this->conf['singlePid'])
						.'<br>';
				} else {
					$content = $this->pi_getLL('error_saving_video');
					$content .= implode('',$this->status);
					$content .= $this->submitFormVideoPictures();
				}
			} else {
				$content = $this->submitFormVideoPictures();
			}
		} else if ($listFunction == 9) {
			if ($GLOBALS['TSFE']->fe_user->user == false) {
				$content = '<p>' . $this->pi_getLL('user_not_logedin') .' </p>';
				return $this->pi_wrapInBaseClass($content);
			}
			
			if (isset($this->piVars['title'])) {
				
				if ($this->saveUserInputToDatabaseOnlyMessage()) {
					$content = 'Beskeden er gemt...';
					$content .= $this->pi_linkTP_keepPIvars(htmlspecialchars($this->piVars['title']),
						array('movie'=>$this->movieId),
						0,
						0,
						$this->conf['singlePid'])
						.'<br>';
				} else {
					$content = $this->pi_getLL('error_saving_video');
					$content .= $this->submitFormOnlyMessage($this->categoryFromFlex);
				}
			} else {
				if ($this->categoryFromFlex == "") {
					$content = "Please set category";
				}
				else {
					$content = $this->submitFormOnlyMessage($this->categoryFromFlex);
				}
			}

		} else if ($listFunction == 0) {
			$content = $this->singleView($this->piVars['movie']);
		} else if ($listFunction == 1) {
			$content = $this->listView();
		} else if ($listFunction == 6) {
			$content = $this->listCategory($this->piVars['category']);
		} else if ($listFunction == 7) {
			$content = $this->categoryListView($this->categoryFromFlex);
		} else if ($listFunction == 8) {
			$content = $this->simpleListView($this->piVars['category']);
		} else if ($listFunction == 2) {
			$content = $this->simpleView($this->piVars['movie']);
		} else if ($listFunction == 3) {
			$content = $this->displayUserVideos($this->piVars['useruid']);
		}else if ($listFunction == 10) {
			$content = $this->listCategoryOnlyMessages($this->categoryFromFlex);
		}else if ($listFunction == 11) {
			$content = $this->singleViewOnlyMessage($this->piVars['movie']);
		}else if ($listFunction == 12) {
			$content = $this->listCategory($this->categoryFromFlex);
		}else if ($listFunction == 14) {
			$content = $this->listCategoryVideoPictures($this->categoryFromFlex);	
		}else if ($listFunction == 15) {
			$content = $this->singleViewVideoPictures($this->piVars['movie']);	
		}else if ($listFunction == 17) {
			$content = $this->showResults($this->categoryFromFlex);
		}

		return $this->pi_wrapInBaseClass($content);
	}

	function categoryListView($catid) {
		//list the categories, for doing stuff
		//must link to the page, which have the cat list view
			
		$catid = implode(",", $catid);
		$rows = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
	   		"tx_videoconnection_videos_categories.uid, categoryName",
	   		"tx_videoconnection_videos_categories INNER JOIN tx_videoconnection_videos ON tx_videoconnection_videos.category = tx_videoconnection_videos_categories.uid",
			'tx_videoconnection_videos_categories.uid in ('. $catid .')',
			'tx_videoconnection_videos_categories.uid'
	   	);

		if (count($rows) == 0) {

			$error = '';
			$template = $this->cObj->getSubpart($this->templateCode,'###LIST_VIEW_NO_VIDEO###');
			$error = $this->cObj->substitutemarker($template,'###TEXT_VIDEO_NOT_FOUND###',$this->pi_getLL('video_not_found'));

		} else {	

			$template = $this->cObj->getSubpart($this->templateCode,'###CATEGORIES_LIST_ITEM###');
			$alt = 1;

			foreach ($rows as $row) {

				$uid = $row['uid'];

				$markerArray = array(
				'###ALTERNATE###' => '-' . ($alt + 1),
				'###CATEGORYNAME###' => $this->pi_linkTP_keepPIvars($row['categoryName'],array('category'=>$uid),0,0,$this->conf['categoryPid']),
				);

				$content[] = $this->cObj->substituteMarkerArray($template, $markerArray);
				$alt = ($alt + 1) % 2;
			}

			return implode($content, ' ');
		}

		return  $error;


	}

	function listCategory($catid) {
		$catid = implode(",", $catid);
		if($catid == "") {
			return 'Please set minimum one category';
		}

		$page = max(0, intval($this->piVars['page']));

		$start = $this->rpp*$page;
		
		list($row) = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('COUNT(*) AS counter',
			'tx_videoconnection_videos', 'category in ('.$catid.') and deleted != 1');

		$numberOfPages = intval($row['counter']/$this->rpp) + (($row['counter'] % $this->rpp) == 0 ? 0 : 1);

		// Get records
		$sorting = 'uid';

		$rows = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
			"uid,title,url,type_of_player,the_valueable_bits,owner,description,category",
			"tx_videoconnection_videos", 
			'category in ('.$catid. ') ' . $this->cObj->enableFields('tx_videoconnection_videos'), 
			'', 
			$sorting, 
			$start . ',' . $this->rpp);

		if (count($rows) == 0) {

			$error = '';
			$template = $this->cObj->getSubpart($this->templateCode,'###LIST_VIEW_NO_VIDEO###');
			$error = $this->cObj->substitutemarker($template,'###TEXT_VIDEO_NOT_FOUND###',$this->pi_getLL('video_not_found'));

		} else {	

			$template = $this->cObj->getSubpart($this->templateCode,'###LIST_ITEM###');
			$alt = 1;

			foreach ($rows as $row) {

				$uid = $row['uid'];

				$username = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
					"name",
					"fe_users",
					"uid=".$GLOBALS['TYPO3_DB']->fullQuoteStr($row['owner'],'fe_users')
					);
					
				$linkConf = array(	
						'movie'=>$uid,
						'category'=>$row['category']
						);

				$markerArray = array(
				'###ALTERNATE###' => '-' . ($alt + 1),
				'###VIDEOPLAYER###' => $this-> displayVideo($row['type_of_player'],$row['the_valueable_bits']),
				'###VIDEOPLAYER_SMALL###' => $this-> displayVideoSmall($row['type_of_player'],$row['the_valueable_bits']),
				'###VIDEOPLAYER_MINI###' => $this-> displayVideoMini($row['type_of_player'],$row['the_valueable_bits']),
				'###THUMBNAIL###' => $this->pi_linkTP_keepPIvars(
					'<img width="200" height="150" src="'.$this->getThumbnail($row['type_of_player'],$row['the_valueable_bits'],3).'" alt="Indl�ser..." /> ',
						$linkConf, 0, 0,
						$this->conf['singlePid']),
				'###THUMBNAIL_SMALL###' => $this->pi_linkTP_keepPIvars(
					'<img width="62" height="50" src="'.$this->getThumbnail($row['type_of_player'],$row['the_valueable_bits'],3).'" alt="Indl�ser..." /> ',
						$linkConf, 0, 0,
						$this->conf['singlePid']),
				'###LINK_TO_SINGLE_W_TITLE###' => $this->pi_linkTP_keepPIvars(
					$row['title'],
						$linkConf, 0, 0,
						$this->conf['singlePid']),
				'###TEXT_TITLE###' => $this->pi_getLL('text_title_list'),
				'###FIELD_TITLE###' => 	$row['title'],
				'###TEXT_UPLOADER###' => $this->pi_getLL('text_uploader_list'),
				'###FIELD_UPLOADER###' => $username[0]['name'],
				'###TEXT_DESCRIPTION###' => $this->pi_getLL('text_description_list'),
				'###FIELD_DESCRIPTION###' => $row['description'],
				'###TEXT_COMMENTS###' => $this->pi_getLL('text_comments_list'),
				'###FIELD_COMMENTS###' => $this->getComments($this->cpp,$uid),
				);


				$content[] = $this->cObj->substituteMarkerArray($template, $markerArray);
				$alt = ($alt + 1) % 2;
			}

			// Fetch template
			$template = $this->cObj->getSubpart($this->templateCode,'###PAGER_AREA###');

			$markers['###PAGER###'] = $this->getListGetPageBrowser($numberOfPages);

			$content[] = $this->cObj->substituteMarkerArray($template, $markers);

			return implode($content, ' ');
		}

		return  $error;
	}
	
	function listCategoryOnlyMessages($catid) {
		//list all videos in a category

		if($catid == "") {
			return 'Please set minimum one category';
		}

		$page = max(0, intval($this->piVars['page']));

		$start = $this->rpp*$page;
		
		$catid = implode(",", $catid);
		
		list($row) = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('COUNT(*) AS counter',
			'tx_videoconnection_videos', 'category in ('.$catid.') and deleted != 1');

		$numberOfPages = intval($row['counter']/$this->rpp) + (($row['counter'] % $this->rpp) == 0 ? 0 : 1);

		// Get records
		$sorting = 'uid desc';

		$rows = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
			"uid,title,url,type_of_player,the_valueable_bits,owner,description,category",
			"tx_videoconnection_videos", 
			'category in ('.$catid.')' . $this->cObj->enableFields('tx_videoconnection_videos'), 
			'', 
			$sorting, 
			$start . ',' . $this->rpp);


		if (count($rows) == 0) {

			$error = $catid.'';
			$template = $this->cObj->getSubpart($this->templateCode,'###LIST_VIEW_NO_VIDEO###');
			$error = $this->cObj->substitutemarker($template,'###TEXT_VIDEO_NOT_FOUND###',$this->pi_getLL('video_not_found'));

		} else {	

			$template = $this->cObj->getSubpart($this->templateCode,'###LIST_ITEM_ONLY_MESSAGES###');
			$alt = 1;

			foreach ($rows as $row) {

				$uid = $row['uid'];

				$username = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
					"name",
					"fe_users",
					"uid=".$GLOBALS['TYPO3_DB']->fullQuoteStr($row['owner'],'fe_users')
					);
					
				$linkConf = array(	
						'movie'=>$uid,
						'category'=>$row['category']
						);

				$markerArray = array(
				'###ALTERNATE###' => '-' . ($alt + 1),
				'###LINK_TO_SINGLE_W_TITLE###' => $this->pi_linkTP_keepPIvars(
					$row['title'],
						$linkConf, 0, 0,
						$this->conf['singlePid']),
				'###TEXT_TITLE###' => $this->pi_getLL('text_title_list'),
				'###FIELD_TITLE###' => 	$row['title'],
				'###TEXT_UPLOADER###' => $this->pi_getLL('text_uploader_list'),
				'###FIELD_UPLOADER###' => $username[0]['name'],
				'###TEXT_DESCRIPTION###' => $this->pi_getLL('text_description_list'),
				'###FIELD_DESCRIPTION###' => $row['description'],
				'###TEXT_COMMENTS###' => $this->pi_getLL('text_comments_list'),
				'###FIELD_COMMENTS###' => $this->getComments($this->cpp,$uid),
				);


				$content[] = $this->cObj->substituteMarkerArray($template, $markerArray);
				$alt = ($alt + 1) % 2;
			}

			// Fetch template
			$template = $this->cObj->getSubpart($this->templateCode,'###PAGER_AREA###');

			$markers['###PAGER###'] = $this->getListGetPageBrowser($numberOfPages);

			$content[] = $this->cObj->substituteMarkerArray($template, $markers);

			return implode($content, ' ');
		}

		return  $error;
	}
	
	function listCategoryVideoPictures($catid) {
		
		if($catid == "") {
			return 'Please set minimum one category';
		}

		$page = max(0, intval($this->piVars['page']));

		$start = $this->rpp*$page;
		
		$catid = implode(",", $catid);
		
		list($row) = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('COUNT(*) AS counter',
			'tx_videoconnection_videos', 'category in ('.$catid.') and deleted != 1');

		$numberOfPages = intval($row['counter']/$this->rpp) + (($row['counter'] % $this->rpp) == 0 ? 0 : 1);

		// Get records
		$sorting = 'uid desc';

		$rows = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
			"uid,title,url,type_of_player,the_valueable_bits,owner,description,category,file1",
			"tx_videoconnection_videos", 
			'category='.$catid . $this->cObj->enableFields('tx_videoconnection_videos'), 
			'', 
			$sorting, 
			$start . ',' . $this->rpp);


		if (count($rows) == 0) {

			$error = '';
			$template = $this->cObj->getSubpart($this->templateCode,'###LIST_VIEW_NO_VIDEO###');
			$error = $this->cObj->substitutemarker($template,'###TEXT_VIDEO_NOT_FOUND###',$this->pi_getLL('video_not_found'));

		} else {	

			$template = $this->cObj->getSubpart($this->templateCode,'###LIST_ITEM###');
			$alt = 1;

			foreach ($rows as $row) {

				$uid = $row['uid'];

				$username = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
					"name",
					"fe_users",
					"uid=".$GLOBALS['TYPO3_DB']->fullQuoteStr($row['owner'],'fe_users')
					);
					
				$linkConf = array(	
						'movie'=>$uid,
						'category'=>$row['category']
						);

				if($row['url'] != null) {
					$markerArray = array(
					'###ALTERNATE###' => '-' . ($alt + 1),
					'###VIDEOPLAYER###' => $this-> displayVideo($row['type_of_player'],$row['the_valueable_bits']),
					'###VIDEOPLAYER_SMALL###' => $this-> displayVideoSmall($row['type_of_player'],$row['the_valueable_bits']),
					'###VIDEOPLAYER_MINI###' => $this-> displayVideoMini($row['type_of_player'],$row['the_valueable_bits']),
					'###THUMBNAIL###' => $this->pi_linkTP_keepPIvars(
						'<img width="200" height="150" src="'.$this->getThumbnail($row['type_of_player'],$row['the_valueable_bits'],3).'" alt="Indl�ser..." /> ',
							$linkConf, 0, 0,
							$this->conf['singlePid']),
					'###THUMBNAIL_SMALL###' => $this->pi_linkTP_keepPIvars(
						'<img width="62" height="50" src="'.$this->getThumbnail($row['type_of_player'],$row['the_valueable_bits'],3).'" alt="Indl�ser..." /> ',
							$linkConf, 0, 0,
							$this->conf['singlePid']),
					'###LINK_TO_SINGLE_W_TITLE###' => $this->pi_linkTP_keepPIvars(
						$row['title'],
							$linkConf, 0, 0,
							$this->conf['singlePid']),
					'###TEXT_TITLE###' => $this->pi_getLL('text_title_list'),
					'###FIELD_TITLE###' => 	$row['title'],
					'###TEXT_UPLOADER###' => $this->pi_getLL('text_uploader_list'),
					'###FIELD_UPLOADER###' => $username[0]['name'],
					'###TEXT_DESCRIPTION###' => $this->pi_getLL('text_description_list'),
					'###FIELD_DESCRIPTION###' => $row['description'],
					'###TEXT_COMMENTS###' => $this->pi_getLL('text_comments_list'),
					'###FIELD_COMMENTS###' => $this->getComments($this->cpp,$uid),
					);
				}
				else {
					$imgConf['file.']['width'] = 200 . 'm';
					$imgConf['file.']['height'] = 150 . 'm';
					$imgConf['file'] = $row['file1'];
					$imgOutput = $this->cObj->IMAGE($imgConf); 
					 
					$markerArray = array(
					'###ALTERNATE###' => '-' . ($alt + 1),
					'###THUMBNAIL###' => $this->pi_linkTP_keepPIvars($imgOutput,
							$linkConf, 0, 0,
							$this->conf['singlePid']),
					'###THUMBNAIL_SMALL###' => $this->pi_linkTP_keepPIvars(
						'<img width="62" height="50" src="'.$row['file1'].'" alt="Indl�ser..." /> ',
							$linkConf, 0, 0,
							$this->conf['singlePid']),
					'###LINK_TO_SINGLE_W_TITLE###' => $this->pi_linkTP_keepPIvars(
						$row['title'],
							$linkConf, 0, 0,
							$this->conf['singlePid']),
					'###TEXT_TITLE###' => $this->pi_getLL('text_title_list'),
					'###FIELD_TITLE###' => 	$row['title'],
					'###TEXT_UPLOADER###' => $this->pi_getLL('text_uploader_list'),
					'###FIELD_UPLOADER###' => $username[0]['name'],
					'###TEXT_DESCRIPTION###' => $this->pi_getLL('text_description_list'),
					'###FIELD_DESCRIPTION###' => $row['description'],
					'###TEXT_COMMENTS###' => $this->pi_getLL('text_comments_list'),
					'###FIELD_COMMENTS###' => $this->getComments($this->cpp,$uid),
					);
				}


				$content[] = $this->cObj->substituteMarkerArray($template, $markerArray);
				$alt = ($alt + 1) % 2;
			}

			// Fetch template
			$template = $this->cObj->getSubpart($this->templateCode,'###PAGER_AREA###');

			$markers['###PAGER###'] = $this->getListGetPageBrowser($numberOfPages);

			$content[] = $this->cObj->substituteMarkerArray($template, $markers);

			return implode($content, ' ');
		}

		return  $error;
	}

	function listView() {

		$page = max(0, intval($this->piVars['page']));

		$start = $this->rpp*$page;

		list($row) = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('COUNT(*) AS counter',
			'tx_videoconnection_videos',
			'pid=' . $this->piVars['pid'] . $this->cObj->enableFields('tx_videoconnection_videos') . ' and deleted != 1');


		$numberOfPages = intval($row['counter']/$this->rpp) + (($row['counter'] % $this->rpp) == 0 ? 0 : 1);

		// Get records
		$sorting = 'uid desc';

		$rows = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
			"uid,title,url,type_of_player,the_valueable_bits,owner,description,category",
			"tx_videoconnection_videos", 
			'pid=' . $this->piVars['pid'] . $this->cObj->enableFields('tx_videoconnection_videos'),
			'', 
			$sorting, 
			$start . ',' . $this->rpp);

		// If no videos found
		if (count($rows) == 0) {

			$error = '';
			$template = $this->cObj->getSubpart($this->templateCode,'###LIST_VIEW_NO_VIDEO###');
			$error = $this->cObj->substitutemarker($template,'###TEXT_VIDEO_NOT_FOUND###',$this->pi_getLL('video_not_found'));

		} else {	// Videos is found

			$template = $this->cObj->getSubpart($this->templateCode,'###LIST_ITEM###');
			$alt = 1;

			foreach ($rows as $row) {

				$uid = $row['uid'];

				$username = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
					"name",
					"fe_users",
					"uid=".$GLOBALS['TYPO3_DB']->fullQuoteStr($row['owner'],'fe_users')
					);
					
				$linkConf = array(	
						'movie'=>$uid,
						'category'=>$row['category'] 
						);

				$markerArray = array(
				'###ALTERNATE###' => '-' . ($alt + 1),
				'###VIDEOPLAYER###' => $this-> displayVideo($row['type_of_player'],$row['the_valueable_bits']),
				'###VIDEOPLAYER_SMALL###' => $this-> displayVideoSmall($row['type_of_player'],$row['the_valueable_bits']),
				'###VIDEOPLAYER_MINI###' => $this-> displayVideoMini($row['type_of_player'],$row['the_valueable_bits']),
				'###THUMBNAIL###' => $this->pi_linkTP_keepPIvars(
					'<img width="200" height="150" src="'.$this->getThumbnail($row['type_of_player'],$row['the_valueable_bits'],3).'" alt="Indl�ser..." /> ',
						$linkConf, 0, 0,
						$this->conf['singlePid']),
				'###THUMBNAIL_SMALL###' => $this->pi_linkTP_keepPIvars(
					'<img width="62" height="50" src="'.$this->getThumbnail($row['type_of_player'],$row['the_valueable_bits'],3).'" alt="Indl�ser..." /> ',
						$linkConf, 0, 0,
						$this->conf['singlePid']),
				'###LINK_TO_SINGLE_W_TITLE###' => $this->pi_linkTP_keepPIvars(
					$row['title'],
						$linkConf, 0, 0,
						$this->conf['singlePid']),
				'###TEXT_TITLE###' => $this->pi_getLL('text_title_list'),
				'###FIELD_TITLE###' => 	$row['title'],
				'###TEXT_UPLOADER###' => $this->pi_getLL('text_uploader_list'),
				'###FIELD_UPLOADER###' => $username[0]['name'],
				'###TEXT_DESCRIPTION###' => $this->pi_getLL('text_description_list'),
				'###FIELD_DESCRIPTION###' => $row['description'],
				'###TEXT_COMMENTS###' => $this->pi_getLL('text_comments_list'),
				'###FIELD_COMMENTS###' => $this->getComments($this->cpp,$uid),
				);


				$content[] = $this->cObj->substituteMarkerArray($template, $markerArray);
				$alt = ($alt + 1) % 2;
			}

			// Fetch template
			$template = $this->cObj->getSubpart($this->templateCode,'###PAGER_AREA###');

			$markers['###PAGER###'] = $this->getListGetPageBrowser($numberOfPages);

			$content[] = $this->cObj->substituteMarkerArray($template, $markers);

			return implode($content, ' ');
		}

		return  $error;
	}
	

	function simpleListView($catid) {

		// Get records
		$sorting = 'rand()';

		$videos = 6;

		$rows = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
			"uid,title,type_of_player,the_valueable_bits,category",
			"tx_videoconnection_videos",
			'pid=' . $this->piVars['pid'] . ' AND category='.$catid . $this->cObj->enableFields('tx_videoconnection_videos'),  
			'', 
			$sorting, 
			$videos
			);


		if (count($rows) == 0) {

			$error = '';
			$template = $this->cObj->getSubpart($this->templateCode,'###LIST_VIEW_NO_VIDEO###');
			$error = $this->cObj->substitutemarker($template,'###TEXT_VIDEO_NOT_FOUND###',$this->pi_getLL('video_not_found'));

		} else {	
			
			$template = $this->cObj->getSubpart($this->templateCode,'###SIMPLE_LIST_ITEM###');

			$alt = 1;

			foreach ($rows as $row) {

				$uid = $row['uid'];

				$username = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
					"name",
					"fe_users",
					"uid=".$GLOBALS['TYPO3_DB']->fullQuoteStr($row['owner'],'fe_users')
					);
					
				$linkConf = array(	
						'movie'=>$uid,
						'category'=>$row['category']
						);
				
				$markerArray = array(
				'###ALTERNATE###' => '-' . ($alt + 1),
				'###VIDEOPLAYER###' => $this-> displayVideo($row['type_of_player'],$row['the_valueable_bits']),
				'###VIDEOPLAYER_SMALL###' => $this-> displayVideoSmall($row['type_of_player'],$row['the_valueable_bits']),
				'###VIDEOPLAYER_MINI###' => $this-> displayVideoMini($row['type_of_player'],$row['the_valueable_bits']),
				'###THUMBNAIL###' => $this->pi_linkTP_keepPIvars(
					'<img width="200" height="150" src="'.$this->getThumbnail($row['type_of_player'],$row['the_valueable_bits'],3).'" alt="Indl�ser..." /> ',
						$linkConf, 0, 0,
						$this->conf['singlePid']),
				'###THUMBNAIL_SMALL###' => $this->pi_linkTP_keepPIvars(
					'<img width="62" height="50" src="'.$this->getThumbnail($row['type_of_player'],$row['the_valueable_bits'],3).'" alt="Indl�ser..." /> ',
						$linkConf, 0, 0,
						$this->conf['singlePid']),
				'###LINK_TO_SINGLE_W_TITLE###' => $this->pi_linkTP_keepPIvars(
					$row['title'],
						$linkConf, 0, 0,
						$this->conf['singlePid']),
				'###TEXT_TITLE###' => $this->pi_getLL('text_title_list'),
				'###FIELD_TITLE###' => 	$row['title'],
				'###CATEGORYNAME###' => $this->pi_linkTP_keepPIvars($row['categoryName'],array('category'=>$uid),0,0,$this->conf['categoryPid']),
				);


				$content[] = $this->cObj->substituteMarkerArray($template, $markerArray);
				$alt = ($alt + 1) % 2;
			}

			// Fetch template
			$template = $this->cObj->getSubpart($this->templateCode,'###PAGER_AREA###');

			$markers['###PAGER###'] = $this->getListGetPageBrowser($numberOfPages);

			$content[] = $this->cObj->substituteMarkerArray($template, $markers);

			return implode($content, ' ');
		}

		return  $error;
	}

	function simpleView() {

		
//		$vidId = $this->conf['simpleVidId'];

		if ($this->simpleView == 0){
			$sorting = 'rand()';
			
			$rows = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
				"uid,title,url,type_of_player,the_valueable_bits,owner,description,category",
				"tx_videoconnection_videos",
				"pid = " .$this->conf['storagePid'],
				"",
				"$sorting",
				"1"
				);
		} else if ($this->simpleView == 1) {
			$sorting = 'times_played DESC';
			
			$rows = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
				"uid,title,url,type_of_player,the_valueable_bits,owner,description,category",
				"tx_videoconnection_videos",
				"",
				"",
				"$sorting",
				"1"
				);
			
		} else if ($this->simpleView == 2) {
			$sorting = 'UID DESC';

			$rows = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
				"uid,title,url,type_of_player,the_valueable_bits,owner,description,category",
				"tx_videoconnection_videos",
				"",
				"",
				"$sorting",
				"1"
				);

		} else if ($this->simpleView == 3) {
		
			$rows = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
				"uid,title,url,type_of_player,the_valueable_bits,owner,description,category",
				"tx_videoconnection_videos",
				"uid=".$this->simpleVideoUID,
				"",
				"",
				"1"
				);

		}
			

		if (count($rows) == 0) {

			$error = '';
			$template = $this->cObj->getSubpart($this->templateCode,'###SIMPLE_VIEW_NO_VIDEO###');
			$error = $this->cObj->substitutemarker($template,'###TEXT_VIDEO_NOT_FOUND###',$this->pi_getLL('video_not_found'));

		} else {	

			$template = $this->cObj->getSubpart($this->templateCode,'###SIMPLE_VIEW###');

			foreach ($rows as $row) {
				
				$uid = $row['uid'];

				$username = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows( 
					"name",
					"fe_users",
					"uid=".$GLOBALS['TYPO3_DB']->fullQuoteStr($row['owner'],'fe_users')
					);
					
				$linkConf = array(	
						'movie'=>$uid,
						'category'=>$row['category'] 
						);
				
				// Max length of the description text (+ '...')
				$maxLength = 80;		
				
				// Cut description off
				$description = $this->wordlimit($row['description'], 80);
							
				$markerArray = array(
				'###VIDEOPLAYER###' => $this-> displayVideo($row['type_of_player'],$row['the_valueable_bits']),
				'###VIDEOPLAYER_SMALL###' => $this-> displayVideoSmall($row['type_of_player'],$row['the_valueable_bits']),
				'###VIDEOPLAYER_MINI###' => $this-> displayVideoMini($row['type_of_player'],$row['the_valueable_bits']),
				'###THUMBNAIL###' => $this->pi_linkTP_keepPIvars(
					'<img width="200" height="150" src="'.$this->getThumbnail($row['type_of_player'],$row['the_valueable_bits'],3).'" alt="Indl�ser..." /> ',
						$linkConf, 0, 0,
						$this->conf['singlePid']),
				'###THUMBNAIL_SMALL###' => $this->pi_linkTP_keepPIvars(
					'<img width="62" height="50" src="'.$this->getThumbnail($row['type_of_player'],$row['the_valueable_bits'],3).'" alt="Indl�ser..." /> ',
						$linkConf, 0, 0,
						$this->conf['singlePid']),
				'###LINK_TO_SINGLE_W_TITLE###' =>$this->pi_linkTP_keepPIvars($row['title'],
						$linkConf, 0, 0,
						$this->conf['singlePid']),
				'###LINK_TO_LIST_VIEW###' => $this->pi_linkToPage($this->pi_getLL('link_to_list_view'),$this->conf['listPid']),
				'###TEXT_TITLE###' => $this->pi_getLL('text_title_list'),
				'###FIELD_TITLE###' => 	$row['title'],
				'###TEXT_UPLOADER###' => $this->pi_getLL('text_uploader_simple'),
				'###FIELD_UPLOADER###' => $username[0]['name'],
				'###TEXT_DESCRIPTION###' => $this->pi_getLL('text_description_simple'),
				'###FIELD_DESCRIPTION###' => $description,
				'###TEXT_COMMENTS###' => $this->pi_getLL('text_comments_simple'),
				'###FIELD_COMMENTS###' => $this->getComments($this->cpp,$vidId),
				);

				$content[] = $this->cObj->substituteMarkerArray($template, $markerArray);
			}
			return implode($content, ' ');
		}
		return  $error;
	}

	function singleView($vidId = -1) {
		if ($vidId == -1)
			return '';

		$rows = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
			"uid,title,url,type_of_player,the_valueable_bits,description,owner,category",
			"tx_videoconnection_videos",
			"uid=".$GLOBALS['TYPO3_DB']->fullQuoteStr($vidId,'tx_videoconnection_videos')
			);

		if (count($rows) == 0) {

			$error = '';
			$template = $this->cObj->getSubpart($this->templateCode,'###SINGLE_VIEW_NO_VIDEO###');
			$error = $this->cObj->substitutemarker($template,'###TEXT_VIDEO_NOT_FOUND###',$this->pi_getLL('video_not_found'));

		} else {	

			$template = $this->cObj->getSubpart($this->templateCode,'###SINGLE_VIEW###');

			foreach ($rows as $row) {

				$username = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
					"name",
					"fe_users",
					"uid=".$GLOBALS['TYPO3_DB']->fullQuoteStr($row['owner'],'fe_users')
					);
					
				$category = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
					"categoryName",
					"tx_videoconnection_videos_categories",
					"uid=".$row['category']
					);
					
				($this->conf['fdfuserPid']=="") ? $param = 607 : $param = $this->conf['fdfuserPid'];
		 		$confLink = array(
		 			"parameter" => $param,
		 	  		"wrap" => "|",
		 	  		"ATagBeforeWrap" => "1",
		 	  		"additionalParams." => array(
		 	  			"dataWrap" => "&tx_fdfuser_pi1[uid]=".$row['owner']
		 	  		)
		 		);

				$markerArray = array(
				'###VIDEOPLAYER###' => $this-> displayVideo($row['type_of_player'],$row['the_valueable_bits']),
				'###VIDEOPLAYER_SMALL###' => $this-> displayVideoSmall($row['type_of_player'],$row['the_valueable_bits']),
				'###VIDEOPLAYER_MINI###' => $this-> displayVideoMini($row['type_of_player'],$row['the_valueable_bits']),
				'###LINK_TO_LIST_VIEW###' => $this->pi_linkToPage($this->pi_getLL('link_to_list_view'),$this->conf['listPid']),					
				'###TEXT_TITLE###' => $this->pi_getLL('text_title_single'),
				'###FIELD_TITLE###' => 	$row['title'],
				'###TEXT_CATEGORY###' => $this->pi_getLL('text_category_single'),
				'###FIELD_CATEGORY###' => 	$category[0]['categoryName'],
				'###TEXT_UPLOADER###' => $this->pi_getLL('text_uploader_single'),
				'###FIELD_UPLOADER###' => $username[0]['name'],
				'###FIELD_UPLOADER_W_LINK###' => $this->cObj->typoLink($username[0]['name'],$confLink),
				'###TEXT_DESCRIPTION###' => $this->pi_getLL('text_description_single'),
				'###FIELD_DESCRIPTION###' => nl2br($row['description']),
				'###TEXT_COMMENTS###' => $this->pi_getLL('text_comments_single'),
				'###FIELD_COMMENTS###' => $this->getComments($this->cpp,$vidId),
				'###COMMENT_LINK###' => '<a href="#tx-comments-comment-form">'.$this->pi_getLL('write_a_comment').'</a>'
				);

				$content[] = $this->cObj->substituteMarkerArray($template, $markerArray);

			}
			$content = preg_replace('|###.*?###|i', '', implode($content, ' ')); // Clear not filled markers
			return $content;
		}

		return  $error;
	}
	
	
	
	function singleViewVideoPictures($vidId = -1) {
		if ($vidId == -1)
			return '';

		$rows = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
			"uid,title,url,type_of_player,the_valueable_bits,description,owner,category,file1,file2,file3",
			"tx_videoconnection_videos",
			"uid=".$GLOBALS['TYPO3_DB']->fullQuoteStr($vidId,'tx_videoconnection_videos')
			);

		if (count($rows) == 0) {

			$error = '';
			$template = $this->cObj->getSubpart($this->templateCode,'###SINGLE_VIEW_NO_VIDEO###');
			$error = $this->cObj->substitutemarker($template,'###TEXT_VIDEO_NOT_FOUND###',$this->pi_getLL('video_not_found'));

		} else {	

			$template = $this->cObj->getSubpart($this->templateCode,'###SINGLE_VIEW###');

			foreach ($rows as $row) {

				$username = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
					"name",
					"fe_users",
					"uid=".$GLOBALS['TYPO3_DB']->fullQuoteStr($row['owner'],'fe_users')
					);
					
				$category = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
					"categoryName",
					"tx_videoconnection_videos_categories",
					"uid=".$row['category']
					);
					
				($this->conf['fdfuserPid']=="") ? $param = 607 : $param = $this->conf['fdfuserPid'];
		 		$confLink = array(
		 			"parameter" => $param,
		 	  		"wrap" => "|",
		 	  		"ATagBeforeWrap" => "1",
		 	  		"additionalParams." => array(
		 	  			"dataWrap" => "&tx_fdfuser_pi1[uid]=".$row['owner']
		 	  		)
		 		);

				$markerArray = array(
				'###LINK_TO_LIST_VIEW###' => $this->pi_linkToPage($this->pi_getLL('link_to_list_view_pascal'),$this->conf['listPid']),					
				'###TEXT_TITLE###' => $this->pi_getLL('text_title_single'),
				'###FIELD_TITLE###' => 	$row['title'],
				'###TEXT_CATEGORY###' => $this->pi_getLL('text_category_single'),
				'###FIELD_CATEGORY###' => 	$category[0]['categoryName'],
				'###TEXT_UPLOADER###' => $this->pi_getLL('text_uploader_single'),
				'###FIELD_UPLOADER###' => $username[0]['name'],
				'###FIELD_UPLOADER_W_LINK###' => $this->cObj->typoLink($username[0]['name'],$confLink),
				'###TEXT_DESCRIPTION###' => $this->pi_getLL('text_description_single'),
				'###FIELD_DESCRIPTION###' => $row['description'],
				'###TEXT_COMMENTS###' => $this->pi_getLL('text_comments_single'),
				'###FIELD_COMMENTS###' => $this->getComments($this->cpp,$vidId),
				'###COMMENT_LINK###' => '<a href="#tx-comments-comment-form">'.$this->pi_getLL('write_a_comment').'</a>'
				);
				
				if($row['url'] != null) {
				$markerArray['###VIDEOPLAYER###'] = $this-> displayVideo($row['type_of_player'],$row['the_valueable_bits']);
				$markerArray['###VIDEOPLAYER_SMALL###'] = $this-> displayVideoSmall($row['type_of_player'],$row['the_valueable_bits']);
				$markerArray['###VIDEOPLAYER_MINI###'] = $this-> displayVideoMini($row['type_of_player'],$row['the_valueable_bits']);	
				}
				
				if($row['file1'] != null) {
					$imgConf['file.']['width'] = 700 . 'm';
					$imgConf['file.']['height'] = 500 . 'm';
					$imgConf['file'] = $row['file1'];
					$imgOutput = $this->cObj->IMAGE($imgConf); 
					$markerArray['###PICTURE1###'] = $imgOutput;
				}
				
				if($row['file2'] != null) {
					$imgConf['file.']['width'] = 700 . 'm';
					$imgConf['file.']['height'] = 500 . 'm';
					$imgConf['file'] = $row['file2'];
					$imgOutput = $this->cObj->IMAGE($imgConf); 
					$markerArray['###PICTURE2###'] = $imgOutput;
				}
				
				if($row['file3'] != null) {
					$imgConf['file.']['width'] = 400 . 'm';
					$imgConf['file.']['height'] = 500 . 'm';
					$imgConf['file'] = $row['file3'];
					$imgOutput = $this->cObj->IMAGE($imgConf); 
					$markerArray['###PICTURE3###'] = $imgOutput;
				}

				
				$content[] = $this->cObj->substituteMarkerArray($template, $markerArray);

			}
			
			$content = preg_replace('|###.*?###|i', '', implode($content, ' ')); // Clear not filled markers
			return $content;
		}

		return  $error;
	}
	
	

	function submitFormBig($catid) {
		$catid = implode(",", $catid);
		$cats = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
	   		'uid, categoryName',
	   		'tx_videoconnection_videos_categories',
			'uid in ('.$catid.')'
	   	);

		$catstr = array();
		if (is_array ($cats)){
			foreach ($cats as $cat) {
				$catstr[] = $cat['categoryName'].'='.$cat['uid'];
			}
		} else {
			$catstr[] = null;
		}
			$conf = array();
			$conf = array('data'=>
				$this->pi_getLL('submit_url_label').":|".$this->prefixId."[url]=input|".$this->pi_getLL('submit_input_field')."|| "
				.$this->pi_getLL('submit_title_label').":|".$this->prefixId."[title]=input|".$this->pi_getLL('submit_input_field')."|| "
				.$this->pi_getLL('submit_description_label').":|".$this->prefixId."[description]=textarea|".$this->pi_getLL('submit_description_field')."|| "
				.$this->pi_getLL('submit_category_label').":|".(count($cats) == 1 ? $this->prefixId."[category]=hidden|".$cats[0]['uid'] : $this->prefixId."[category]=select|".implode(",",$catstr))." ||
	   		|submit=submit|".$this->pi_getLL('submit_button_label'),
				'layout' =>  "###LABEL### ###FIELD###<BR>",
			'method'=>"POST",
				'action'=>$this->pi_getPageLink($GLOBALS['TSFE']->id));
			return $this->cObj->FORM($conf);
	}

	function submitFormSmall($catid) {
		$catid = implode(",", $catid);
	   $cats = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
	   		'uid, categoryName',
	   		'tx_videoconnection_videos_categories',
			'uid in ('.$catid.')'
	   	);
	
	   $catstr = array();
	   if (is_array ($cats)){
	   	foreach ($cats as $cat) {
	   		$catstr[] = $cat['categoryName'].'='.$cat['uid'];
	   	}
	   	} else {
	   		$catstr[] = null;
	   	}
	
	   	$conf = array();
	   	$conf = array('data'=>
	   		$this->pi_getLL('submit_url_label').":|".$this->prefixId."[url]=input|".$this->pi_getLL('submit_input_field')."|| "
	   		.$this->pi_getLL('submit_title_label').":|".$this->prefixId."[title]=input|".$this->pi_getLL('submit_input_field')."|| "
	   		.$this->pi_getLL('submit_description_label').":|".$this->prefixId."[description]=textarea|".$this->pi_getLL('submit_description_field')."|| "
	   		.$this->pi_getLL('submit_category_label').":|".(count($cats) == 1 ? $this->prefixId."[category]=hidden|".$cats[0]['uid'] : $this->prefixId."[category]=select|".implode(",",$catstr))." ||
	   		|submit=submit|".$this->pi_getLL('submit_button_label'),
	   		'layout' =>  "###LABEL### ###FIELD###<BR>",
	   	'method'=>"POST",
	   		'action'=>$this->pi_getPageLink($GLOBALS['TSFE']->id));
	   	return $this->cObj->FORM($conf);
	}
	
	function submitFormPictures() {	
		$template = $this->cObj->getSubpart($this->templateCode,'###UPLOAD_PICTURES_FORM###');
	   	$markerArray = array(
				'###VIDEO_LABEL###' => $this->pi_getLL('submit_url_label'),
				'###TITLE_LABEL###' => $this->pi_getLL('submit_title_label'),
				'###DESCRIPTION_LABEL###' => $this->pi_getLL('submit_description_field'),
				'###STATUS###' => ''
				);
		$content[] = $this->cObj->substituteMarkerArray($template, $markerArray);
		$content = preg_replace('|###.*?###|i', '', implode($content, ' ')); // Clear not filled markers
		return $content;		
	}
	
	function submitFormVideoPictures() {	
		$template = $this->cObj->getSubpart($this->templateCode,'###UPLOAD_VIDEO_PICTURES_FORM###');
	   	$markerArray = array(
				'###VIDEO_LABEL###' => $this->pi_getLL('submit_url_label'),
				'###TITLETAG###' => "title=' '",
				'###TITLE_LABEL###' => $this->pi_getLL('submit_title_label'),
				'###PICTURE_LABEL###' => $this->pi_getLL('submit_picture_label'),
				'###DESCRIPTION_LABEL###' => $this->pi_getLL('submit_description_field'),
				'###STATUS###' => ''
				);
		$content[] = $this->cObj->substituteMarkerArray($template, $markerArray);
		$content = preg_replace('|###.*?###|i', '', implode($content, ' ')); // Clear not filled markers
		return $content;		
	}
	
	function submitFormOnlyMessage($catid) {
		$catid = implode(",", $catid);
		$cats = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
	   		'uid, categoryName',
	   		'tx_videoconnection_videos_categories',
			'uid in ('. $catid .')'
	   	);

	   $catstr = array();
	   if (is_array ($cats)){
			foreach ($cats as $cat) {
				$catstr[] = $cat['categoryName'].'='.$cat['uid'];
			}
	   	} else {
	   		$catstr[] = null;
	   	}
	
	   	$conf = array();
	   	$conf = array('data'=>
	   		$this->pi_getLL('submit_title_label').":|".$this->prefixId."[title]=input|".$this->pi_getLL('submit_input_field')."|| "
	   		.$this->pi_getLL('submit_description_label').":|".$this->prefixId."[description]=textarea|".$this->pi_getLL('submit_description_field')."||"
	   		.$this->pi_getLL('submit_category_label').":|".(count($cats) == 1 ? $this->prefixId."[category]=hidden|".$cats[0]['uid'] : $this->prefixId."[category]=select|".implode(",",$catstr))." ||
	   		|submit=submit|".$this->pi_getLL('submit_button_label'),
	   		'layout' =>  "###LABEL### ###FIELD###<BR>",
	   	'method'=>"POST",
	   		'action'=>$this->pi_getPageLink($GLOBALS['TSFE']->id));
	   	return $this->cObj->FORM($conf);
	}


	function getComments($limit,$uid) {
		
  		$rows = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
  			'*', 
  			'tx_comments_comments',
			' external_prefix=' . $GLOBALS['TYPO3_DB']->fullQuoteStr('tx_videoconnection_pi1', 'tx_comments_comments').
	  		' AND external_ref=' . $GLOBALS['TYPO3_DB']->fullQuoteStr('tx_videoconnection_videos_'. $uid, 'tx_comments_comments').
	  		' AND approved = 1  AND hidden = 0 AND deleted = 0',
			'',									//groupe
			'uid DESC', 						//order
			$limit 								//limit
			);

  		$comments = '';

		if (count($rows) == 0) {

			return '<br>Bliv den f&oslash;rste der skriver en kommentar..';
			
		} else {
			
		
			foreach($rows as $row) {
  				$comments .= '<br> '. $row['firstname']. ': '.$row['content'];
  			}

  		return  $comments;
  		}
  	return "Error";
	}

  	function getListGetPageBrowser($numberOfPages) {
  		// Get default configuration
  		$conf = $GLOBALS['TSFE']->tmpl->setup['plugin.']['tx_pagebrowse_pi1.'];
  		// Modify this configuration
  		$conf += array(
  			'pageParameterName' => $this->prefixId . '|page',
  			'numberOfPages' => $numberOfPages,
  			);
  		// Get page browser
  		$cObj = t3lib_div::makeInstance('tslib_cObj');
  		/* @var $cObj tslib_cObj */
  		$cObj->start(array(), '');
  		return $cObj->cObjGetSingle('USER', $conf);
  	}

	function displayUserVideos($useruid) {

		if (!$useruid)	{$useruid = $GLOBALS['TSFE']->fe_user->user['uid'];}

		$page = max(0, intval($this->piVars['page']));

		$start = $this->rpp*$page;

		list($row) = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('COUNT(*) AS counter',
			'tx_videoconnection_videos', "owner=".$useruid . " and deleted != 1");

		$numberOfPages = intval($row['counter']/$this->rpp) + (($row['counter'] % $this->rpp) == 0 ? 0 : 1);

		// Get records
		$sorting = 'uid desc';				

		//get rows from db
		$rows = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
			"title,url,type_of_player,the_valueable_bits,owner",
			"tx_videoconnection_videos",
			"owner=".$useruid,
			'',
			$sorting,
			$start . ',' . $this->rpp
			);

		if (count($rows) == 0) {

			$error = '';
			$template = $this->cObj->getSubpart($this->templateCode,'###LIST_VIEW_NO_VIDEO###');
			$error = $this->cObj->substitutemarker($template,'###TEXT_VIDEO_NOT_FOUND###',$this->pi_getLL('user_video_not_found')
			);

		} else {	

			$template = $this->cObj->getSubpart($this->templateCode,'###LIST_ITEM###');
			$alt = 1;

			foreach ($rows as $row) {

				$uid = $row['uid'];

				$username = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
					"name",
					"fe_users",
					"uid=".$GLOBALS['TYPO3_DB']->fullQuoteStr($row['owner'],'fe_users')
					);

				$markerArray = array(
				'###ALTERNATE###' => '-' . ($alt + 1),
				'###VIDEOPLAYER###' => $this-> displayVideo($row['type_of_player'],$row['the_valueable_bits']),
				'###VIDEOPLAYER_SMALL###' => $this-> displayVideoSmall($row['type_of_player'],$row['the_valueable_bits']),
				'###VIDEOPLAYER_MINI###' => $this-> displayVideoMini($row['type_of_player'],$row['the_valueable_bits']),
				'###THUMBNAIL###' => $this->pi_linkTP_keepPIvars(
					'<img width="200" height="150" src="'.$this->getThumbnail($row['type_of_player'],$row['the_valueable_bits'],3).'" alt="Indl�ser..." /> ',
						$linkConf, 0, 0,
						$this->conf['singlePid']),
				'###THUMBNAIL_SMALL###' => $this->pi_linkTP_keepPIvars(
					'<img width="62" height="50" src="'.$this->getThumbnail($row['type_of_player'],$row['the_valueable_bits'],3).'" alt="Indl�ser..." /> ',
						$linkConf, 0, 0,
						$this->conf['singlePid']),
				'###LINK_TO_SINGLE_W_TITLE###' => $this->pi_linkTP_keepPIvars($row['title'], 								
						array('movie'=>$uid,'category'=>$row['category']),0,0,$this->conf['singlePid']),
				'###TEXT_TITLE###' => $this->pi_getLL('text_title_list'),
				'###FIELD_TITLE###' => 	$row['title'],
				'###TEXT_UPLOADER###' => $this->pi_getLL('text_uploader_list'),
				'###FIELD_UPLOADER###' => $username[0]['name'],
				'###TEXT_DESCRIPTION###' => $this->pi_getLL('text_description_list'),
				'###FIELD_DESCRIPTION###' => $row['description'],
				'###TEXT_COMMENTS###' => $this->pi_getLL('text_comments_list'),
				'###FIELD_COMMENTS###' => $this->getComments($this->cpp,$uid),
				);


				$content[] = $this->cObj->substituteMarkerArray($template, $markerArray);
				$alt = ($alt + 1) % 2;
			}

			// Fetch template
			$template = $this->cObj->getSubpart($this->templateCode,'###PAGER_AREA###');

			$markers['###PAGER###'] = $this->getListGetPageBrowser($numberOfPages);

			$content[] = $this->cObj->substituteMarkerArray($template, $markers);

			return implode($content, ' ');
		}

		return  $error;
	}

	function displayVideo($playerType,$magicWord) {
		if ($playerType == '0') {
			return $this->getYoutubeEmbeddedPlayer($magicWord);
		} else if ($playerType == '2') {
			return $this->getVimeoEmbeddedPlayer($magicWord);
		} else if ($playerType == '1') {
			return $this->getArtoEmbeddedPlayer($magicWord);
		}
	}

	function displayVideoSmall($playerType,$magicWord) {
   		if ($playerType == '0') {
   			return $this->getYoutubeEmbeddedPlayerSmall($magicWord);
   		} else if ($playerType == '2') {
   			return $this->getVimeoEmbeddedPlayer($magicWord);
   		} else if ($playerType == '1') {
   			return $this->getArtoEmbeddedPlayer($magicWord);
   		}
   	}

	function displayVideoMini($playerType,$magicWord) {
	 			if ($playerType == '0') {
	 				return $this->getYoutubeEmbeddedPlayerMini($magicWord);
	 			} else if ($playerType == '2') {
	 					return $this->getVimeoEmbeddedPlayer($magicWord);
	 			} else if ($playerType == '1') {
	 					return $this->getArtoEmbeddedPlayer($magicWord);
	 			}
	}

  	function getYoutubeEmbeddedPlayer($magicWord) {
  		return '<object width="360" height="265">
  			<embed src="http://www.youtube.com/v/'.$magicWord.'&hl=en&fs=1" 
  		type="application/x-shockwave-flash" allowfullscreen="true" width="360" height="265">
  			</embed>
  			</object>';
  	}

  	function getYoutubeEmbeddedPlayerSmall($magicWord) {
  		return '<object width="160" height="132">
  			<embed src="http://www.youtube.com/v/'.$magicWord.'&hl=en&fs=1" 
  		type="application/x-shockwave-flash" allowfullscreen="true" width="160" height="132">
  			</embed>
  			</object>';
  	}

  	function getYoutubeEmbeddedPlayerMini($magicWord) {
  		return '<object width="67" height="66">
  			<embed src="http://www.youtube.com/v/'.$magicWord.'&hl=en&fs=1" 
  		type="application/x-shockwave-flash" allowfullscreen="true" width="67" height="66">
  			</embed>
  			</object>';
  	}

  	function getVimeoEmbeddedPlayer($magicWord) {
		return '<object width="400" height="225">
  			<embed src="http://vimeo.com/moogaloop.swf?clip_id='.$magicWord.'" 
  		type="application/x-shockwave-flash" allowfullscreen="true"	 width="400" height="225">
  			</embed>
  			</object>';
  	}

   	function getArtoEmbeddedPlayer($magicWord) {
   			return '<embed type="application/x-shockwave-flash"
   				src="http://arto.com/section/user/profile/video/embed.ashx/'.$magicWord.'" 
   			allowfullscreen="true" height="395" width="500">';
   	}

	function getThumbnail($playerType,$magicWord,$size) {
		if 		  ($playerType == '0') {
			return $this->getYoutubeThumbnail($magicWord,$size);
		} else if ($playerType == '2') {
			return $this->getVimeoThumbnail($magicWord,$size);
		} else if ($playerType == '1') {
			return $this->getArtoThumbnail($magicWord,$size);
		}
	}
	
	function getYoutubeThumbnail($magicWord,$size) {

			if ($size == '1'){
	  			return 'http://img.youtube.com/vi/'.$magicWord.'/0.jpg';
			} else if ($size == '2') {
	  			return 'http://img.youtube.com/vi/'.$magicWord.'/0.jpg';
			} else if ($size == '3') {
	  			return 'http://img.youtube.com/vi/'.$magicWord.'/0.jpg';
			}
	}

  	function getVimeoThumbnail($magicWord,$size) {

		//connect to vimeo to gather video info
		$url = 'http://vimeo.com/api/clip/'.$magicWord.'/php';
		$contents = @file_get_contents($url);
		$array = @unserialize(trim($contents));

		if ($size == '1'){
  			return $array[0][user_thumbnail_small];
		} else if ($size == '2') {
  			return $array[0][thumbnail_medium];			
		} else if ($size == '3') {
  			return $array[0][user_thumbnail_large];
		}
  	}

 	function getArtoThumbnail($magicWord,$size) {

		//connect to vimeo to gather video info
		$url = 'http://vimeo.com/api/clip/'.$magicWord.'/php';
		$contents = @file_get_contents($url);
		$array = @unserialize(trim($contents));

		if ($size == '1'){
  			return $array[0][user_thumbnail_small];
		} else if ($size == '2') {
  			return $array[0][thumbnail_medium];			
		} else if ($size == '3') {
  			return $array[0][user_thumbnail_large];
		}
  	}


   //TODO: Make sure that the user only add a video which is not added at this moment
   //TODO: Escape entries to db
	function saveUserInputToDatabase() {
		if ($this->getTheValueableBits() && $this->piVars['title']) {
			$dataToInsert = array(
				'pid'				=>$this->piVars['pid'],
				'url'				=>$this->piVars['url'],
				'title'				=>htmlspecialchars($this->piVars['title']),
				'description'		=>htmlspecialchars($this->piVars['description']),
				'category'			=>$this->piVars['category'],
				'the_valueable_bits'=>$this->valueablebits,
				'type_of_player'	=>$this->playerType,
				'owner'				=>$GLOBALS['TSFE']->fe_user->user['uid'],
				'crdate' => time(),
				'tstamp' => time()
		);
 
		$res1 = $GLOBALS['TYPO3_DB']->exec_INSERTquery('tx_videoconnection_videos',$dataToInsert);
		$this->movieId = $GLOBALS['TYPO3_DB']->sql_insert_id();

		#   				$dataToInsert = array(
			#   					'uid_local'=>$this->piVars['category'],
			#   					'uid_foreign'=>$GLOBALS['TYPO3_DB']->sql_insert_id()
			#   					);
			#   				$this->movieId = $GLOBALS['TYPO3_DB']->sql_insert_id();
			#   				$res2 =	$GLOBALS['TYPO3_DB']->exec_INSERTquery('tx_videoconnection_videos_category_mm',$dataToInsert);
			#
			#
			#   				return var_export($res1,true).var_export($res2,true);

			return var_export($res1,true);
		}
		return false;
	}
		
	function saveUserInputToDatabaseOnlyMessage() {
		if ($this->piVars['title']) {
			$dataToInsert = array(
				'pid'				=>$this->piVars['pid'],
				'title'				=>htmlspecialchars($this->piVars['title']),
				'description'		=>htmlspecialchars($this->piVars['description']),
				'category'			=>$this->piVars['category'],
				'owner'			=>$GLOBALS['TSFE']->fe_user->user['uid'],
				'crdate' => time(),
				'tstamp' => time()
			);
 
		$res1 = $GLOBALS['TYPO3_DB']->exec_INSERTquery('tx_videoconnection_videos',$dataToInsert);
		$this->movieId = $GLOBALS['TYPO3_DB']->sql_insert_id();

			return var_export($res1,true);
		}
 
		return false;
	}
	
	function saveUserInputToDatabaseVideoPictures() {
		
		$catid = implode(",", $this->categoryFromFlex);	
		if ($this->piVars['title']) {
			$dataToInsert = array(
				'pid'				=>$this->piVars['pid'],
				'title'				=>htmlspecialchars($this->piVars['title']),
				'description'		=>htmlspecialchars($this->piVars['description']),
				'category'			=>$catid,
				'owner'			=>$GLOBALS['TSFE']->fe_user->user['uid'],
				'crdate' => time(),
				'tstamp' => time()
			);
		if($_FILES[$this->prefixId][name]['picture1'] != null) {$dataToInsert['file1'] = $this->handleUpload('picture1');}
		if($_FILES[$this->prefixId][name]['picture2'] != null) {$dataToInsert['file2'] = $this->handleUpload('picture2');}
		if($_FILES[$this->prefixId][name]['picture3'] != null) {$dataToInsert['file3'] = $this->handleUpload('picture3');}
		
		if ($this->getTheValueableBits()) {
				$dataToInsert['url'] = $this->piVars['url'];
				$dataToInsert['the_valueable_bits'] = $this->valueablebits;
				$dataToInsert['type_of_player'] = $this->playerType;
		}
 
		$res1 = $GLOBALS['TYPO3_DB']->exec_INSERTquery('tx_videoconnection_videos',$dataToInsert);
		$this->movieId = $GLOBALS['TYPO3_DB']->sql_insert_id();

			return var_export($res1,true);
		}
 
		return false;
	}
	
	function handleUpload($file){
		global $TYPO3_CONF_VARS;
		$content='';
		$path = '';
		$this->status = array();
		if($this->conf['path']){
			$path=$this->cObj->stdWrap($this->conf['path'],$this->conf['path.']);
		}
		$uploaddir = is_dir($path)?$path:$TYPO3_CONF_VARS['BE']['fileadminDir'];

		if($GLOBALS["TSFE"]->loginUser){ 
			$feuploaddir=$uploaddir.'pascalfiles/'.$GLOBALS["TSFE"]->fe_user->user["uid"].'/';
			if(!is_dir($feuploaddir)){
				if(!mkdir($feuploaddir)){
					$feuploaddir=$uploaddir;
				}
			}
			$uploaddir = $feuploaddir;
		}
		$catid = implode(",", $this->categoryFromFlex);
		$uploadfile = $uploaddir.$catid.'_'.$_FILES[$this->prefixId][name][$file];
		$uploadfile = str_replace (" ", "", $uploadfile);

		
		
		
		if(is_file($uploadfile) && $this->conf['noOverwrite']){//file already exists?
			$this->status[] = $this->cObj->cObjGetSingle($this->conf['message.']['exist'],$this->conf['message.']['exist.']);
			$this->error[] = 'exists';
		}
		
		if($this->file_too_big($_FILES[$this->prefixId]['size'][$file])){
			$this->status[] = $this->cObj->cObjGetSingle($this->conf['message.']['toobig'],$this->conf['message.']['toobig.']);
			$this->error[] = 'to big';
		}
		
		if(!$this->mime_allowed($_FILES[$this->prefixId]['type'][$file])){ //mimetype allowed?
			$this->status[] =  $this->cObj->cObjGetSingle($this->conf['message.']['mimenotallowed'],$this->conf['message.']['mimenotallowed.']);
			$this->error[] = 'mime';
		}
		
		if(!$this->ext_allowed($_FILES[$this->prefixId]['name'][$file])){ //extension allowed?
			$this->status[] =  $this->cObj->cObjGetSingle($this->conf['message.']['extensionnotallowed'],$this->conf['message.']['extensionnotallowed.']);
			$this->error[] = 'extension';
		}
		
		if(empty($this->status)){ //no errors so far
			if(move_uploaded_file($_FILES[$this->prefixId]['tmp_name'][$file], $uploadfile)) {//succes!
				$filemode = octdec($this->conf['fileMode']);
				@chmod($uploadfile, 0755);
				$this->status[] = $this->cObj->cObjGetSingle($this->conf['message.']['uploadsuccesfull'],$this->conf['message.']['uploadsuccesfull.']);
				return $uploadfile;
	 		} else {
				$this->handle_error($_FILES[$this->prefixId]['error']);
				
			}
		}
		else { return false; }

	}
	
	

	function handle_error($error){

		switch ($error){
			case 0: 
					break;
			case 1:
			case 2:
					$this->status[] = $this->cObj->cObjGetSingle($this->conf['message.']['toobig'],$this->conf['message.']['toobig.']);
					$this->error[] = 'to big';
					break;
			case 3:
					$this->status[] = $this->cObj->cObjGetSingle($this->conf['message.']['partial'],$this->conf['message.']['partial.']);
					$this->error[] = 'partial';
					break;
			case 4:
					$this->status[] = $this->cObj->cObjGetSingle($this->conf['message.']['nofile'],$this->conf['message.']['nofile.']);
					$this->error[] = 'nofile';
					break;
			default:
					$this->status[] = $this->cObj->cObjGetSingle($this->conf['message.']['unknown'],$this->conf['message.']['unknown.']);
					$this->error[] = 'unknown';
					break;
		}
	}

	function mime_allowed($mime){
		$includelist = array('image/gif','image/jpeg','image/png','image/jpg','image/pjpeg');
		$excludelist = array('application/octet-stream','application/x-zip-compressed');		//overrides includelist
		return (   (in_array($mime,$includelist) || in_array('*',$includelist))   &&   (!in_array($mime,$excludelist))  );
	}

	function ext_allowed($filename){
		$includelist = array('jpg','jpeg','png','gif','jpe');
		$excludelist = array('t3x','exe','zip','war','tar','gz','php','php3','asp');	//overrides includelist
		$extension='';
		if($extension=strstr($filename,'.')){
			$extension=substr($extension, 1);
			$extension = strtolower($extension);    
			return ((in_array($extension,$includelist) || in_array('*',$includelist)) && (!in_array($extension,$excludelist)));
		} else {
			return FALSE;
		}
	}
	
	function file_too_big($filesize){
		return $filesize > 10000000;
	}

	
	
	
	
	function singleViewPictures($vidId = -1) {
		if ($vidId == -1)
			return '';

		$rows = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
			"uid,title,description,owner,category",
			"tx_videoconnection_videos",
			"uid=".$GLOBALS['TYPO3_DB']->fullQuoteStr($vidId,'tx_videoconnection_videos')
			);

		if (count($rows) == 0) {

			$error = 'Intet';
			$template = $this->cObj->getSubpart($this->templateCode,'###SINGLE_VIEW_NO_VIDEO###');
			$error .= $this->cObj->substitutemarker($template,'###TEXT_VIDEO_NOT_FOUND###',$this->pi_getLL('video_not_found'));

		} else {	

			$template = $this->cObj->getSubpart($this->templateCode,'###SINGLE_VIEW_ONLY_MESSAGE###');

			foreach ($rows as $row) {

				$username = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
					"name",
					"fe_users",
					"uid=".$GLOBALS['TYPO3_DB']->fullQuoteStr($row['owner'],'fe_users')
					);
					
				$category = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
					"categoryName",
					"tx_videoconnection_videos_categories",
					"uid=".$row['category']
					);
				($this->conf['fdfuserPid']=="") ? $param = 607 : $param = $this->conf['fdfuserPid'];
		 		$confLink = array(
		 			"parameter" => $param,
		 	  		"wrap" => "|",
		 	  		"ATagBeforeWrap" => "1",
		 	  		"additionalParams." => array(
		 	  			"dataWrap" => "&tx_fdfuser_pi1[uid]=".$row['owner']
		 	  		)
		 		);

				$markerArray = array(
				'###LINK_TO_LIST_VIEW###' => $this->pi_linkToPage($this->pi_getLL('link_to_list_view'),$this->conf['listPid']),					
				'###TEXT_TITLE###' => $this->pi_getLL('text_title_single'),
				'###FIELD_TITLE###' => 	$row['title'],
				'###TEXT_CATEGORY###' => $this->pi_getLL('text_category_single'),
				'###FIELD_CATEGORY###' => 	$category[0]['categoryName'],
				'###TEXT_UPLOADER###' => $this->pi_getLL('text_uploader_single'),
				'###FIELD_UPLOADER###' => $username[0]['name'],
				'###FIELD_UPLOADER_W_LINK###' => $this->cObj->typoLink($username[0]['name'],$confLink),
				'###TEXT_DESCRIPTION###' => $this->pi_getLL('text_description_single'),
				'###FIELD_DESCRIPTION###' => nl2br($row['description']),
				'###TEXT_COMMENTS###' => $this->pi_getLL('text_comments_single'),
				'###FIELD_COMMENTS###' => $this->getComments($this->cpp,$vidId),
				'###COMMENT_LINK###' => '<a href="#tx-comments-comment-form">'.$this->pi_getLL('write_a_comment').'</a>'
				);

				$content[] = $this->cObj->substituteMarkerArray($template, $markerArray);

			}
			$content = preg_replace('|###.*?###|i', '', implode($content, ' ')); // Clear not filled markers
			return $content;
		}

		return  $error;
	}


	
	function singleViewOnlyMessage($vidId = -1) {
		if ($vidId == -1)
			return '';

		$rows = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
			"uid,title,description,owner,category",
			"tx_videoconnection_videos",
			"uid=".$GLOBALS['TYPO3_DB']->fullQuoteStr($vidId,'tx_videoconnection_videos')
			);

		if (count($rows) == 0) {

			$error = 'Intet';
			$template = $this->cObj->getSubpart($this->templateCode,'###SINGLE_VIEW_NO_VIDEO###');
			$error .= $this->cObj->substitutemarker($template,'###TEXT_VIDEO_NOT_FOUND###',$this->pi_getLL('video_not_found'));

		} else {	

			$template = $this->cObj->getSubpart($this->templateCode,'###SINGLE_VIEW_ONLY_MESSAGE###');

			foreach ($rows as $row) {

				$username = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
					"name",
					"fe_users",
					"uid=".$GLOBALS['TYPO3_DB']->fullQuoteStr($row['owner'],'fe_users')
					);
					
				$category = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
					"categoryName",
					"tx_videoconnection_videos_categories",
					"uid=".$row['category']
					);
				($this->conf['fdfuserPid']=="") ? $param = 607 : $param = $this->conf['fdfuserPid'];
		 		$confLink = array(
		 			"parameter" => $param,
		 	  		"wrap" => "|",
		 	  		"ATagBeforeWrap" => "1",
		 	  		"additionalParams." => array(
		 	  			"dataWrap" => "&tx_fdfuser_pi1[uid]=".$row['owner']
		 	  		)
		 		);

				$markerArray = array(
				'###LINK_TO_LIST_VIEW###' => $this->pi_linkToPage($this->pi_getLL('link_to_list_view'),$this->conf['listPid']),					
				'###TEXT_TITLE###' => $this->pi_getLL('text_title_single'),
				'###FIELD_TITLE###' => 	$row['title'],
				'###TEXT_CATEGORY###' => $this->pi_getLL('text_category_single'),
				'###FIELD_CATEGORY###' => 	$category[0]['categoryName'],
				'###TEXT_UPLOADER###' => $this->pi_getLL('text_uploader_single'),
				'###FIELD_UPLOADER###' => $username[0]['name'],
				'###FIELD_UPLOADER_W_LINK###' => $this->cObj->typoLink($username[0]['name'],$confLink),
				'###TEXT_DESCRIPTION###' => $this->pi_getLL('text_description_single'),
				'###FIELD_DESCRIPTION###' => nl2br($row['description']),
				'###TEXT_COMMENTS###' => $this->pi_getLL('text_comments_single'),
				'###FIELD_COMMENTS###' => $this->getComments($this->cpp,$vidId),
				'###COMMENT_LINK###' => '<a href="#tx-comments-comment-form">'.$this->pi_getLL('write_a_comment').'</a>'
				);

				$content[] = $this->cObj->substituteMarkerArray($template, $markerArray);

			}
			return implode($content, ' ');
		}

		return  $error;
	}
	
	function wordlimit($string, $length)
	{ 
		$str = wordwrap($string, $length);
		$str = explode("\n", $str);
				
		if (strlen($str[0]) < strlen($string)){
				$str = $str[0] . '...';
			} else {
				$str = $str[0];
		}

		
	    return $str;
	}

	function getTheValueableBits() {
	  		$playerType = '';
	  		$youtube = '/\?v\=([\S*]{11})/'; 	// Done
	  		$vimeo = "/([\d]{7})/";				// Done
	  		$break = "/index\/([\S]*)\.html/";
	  		$myspace = "/([\d]{9})/";
	  		$arto = "/([\d]{6})/";
	  		$valueablebits = '';
	  		$regEx = '';
	  		if (strpos($this->piVars['url'],'youtube') !== false) {
	  			$this->playerType = '0';
	  			$regEx = $youtube;
	  		} else if (strpos($this->piVars['url'],"arto") !== false) {
	  			$this->playerType = '1';
	  			$regEx = $arto;
	  		} else if (strpos($this->piVars['url'],"vimeo") !== false) {
	  			$this->playerType = '2';
	  			$regEx = $vimeo;
	  		} else if (strpos($this->piVars['url'],"break") !== false) {
	  	 		$this->playerType = '3';
	  	 		$regEx = $break;
	  	 	} else if (strpos($this->piVars['url'],"myspace") !== false) {
	  	 		$this->playerType = '4';
	  	 		$regEx = $myspace;
	  	 	} else {
	  	 		return false;
	  	 	}
	  	 	$matchtes = array();
	  	 	preg_match($regEx,$this->piVars['url'],$matches);
	  	 	$this->valueablebits = $matches[1];
        
	  	 	return true;
	}
	
	function showResults($catid) {
		
		if($catid == "") {
			return 'Please set minimum one category';
		}

		$page = max(0, intval($this->piVars['page']));

		$start = $this->rpp*$page;
		
		$catid = implode(",", $catid);
		
		list($row) = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows('COUNT(*) AS counter',
			'tx_videoconnection_videos', 'category in ('.$catid.') and deleted != 1');

		$numberOfPages = intval($row['counter']/$this->rpp) + (($row['counter'] % $this->rpp) == 0 ? 0 : 1);

		// Get records
		$sorting = 'uid';

		$rows = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
			"uid,title,url,type_of_player,the_valueable_bits,owner,description,category,crdate",
			"tx_videoconnection_videos", 
			'category='.$catid . $this->cObj->enableFields('tx_videoconnection_videos'), 
			'', 
			$sorting);

		if (count($rows) == 0) {

			$error = '';
			$template = $this->cObj->getSubpart($this->templateCode,'###LIST_VIEW_NO_VIDEO###');
			$error = $this->cObj->substitutemarker($template,'###TEXT_VIDEO_NOT_FOUND###',$this->pi_getLL('video_not_found'));

		} else {	

			$template = $this->cObj->getSubpart($this->templateCode,'###LIST_ITEM###');
			$alt = 1;

			foreach ($rows as $row) {

				$uid = $row['uid'];

				$userinfo = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
					"u.name,u.address,u.email,u.telephone,a.name AS district",
					"fe_users AS u left outer join tt_address AS a on u.tx_fdfuser_district = a.uid",
					"u.uid=".$GLOBALS['TYPO3_DB']->fullQuoteStr($row['owner'],'fe_users')
					);
					
				$linkConf = array(	
						'movie'=>$uid,
						'category'=>$row['category']
						);

				$markerArray = array(
				'###ALTERNATE###' => '-' . ($alt + 1),
				'###LINK_TO_SINGLE_W_TITLE###' => $row['title'],
				'###FIELD_TITLE###' => $row['title'],
				'###TEXT_UPLOADER###' => $this->pi_getLL('text_uploader_list'),
				'###TEXT_DESCRIPTION###' => $this->pi_getLL('text_description_list'),
				'###FIELD_DESCRIPTION###' => nl2br($row['description'])
				);
				
				$crdate = date('j-m-y - G:i',$row['crdate']);
				
				$markerArray['###FIELD_UPLOADER###'] = "<br />Oprettet: ".$crdate."<br />Navn: " . $userinfo[0]['name']."<br />Adresse: ".$userinfo[0]['address']."<br />Email: ".$userinfo[0]['email']."<br />Telefon: ".$userinfo[0]['telephone']."<br />Kreds: ".$userinfo[0]['district'];
				if($row['url'] != ''){
				$markerArray['###VIDEOPLAYER###'] = $this-> displayVideo($row['type_of_player'],$row['the_valueable_bits']);
				$markerArray['###VIDEOPLAYER_SMALL###'] = $this-> displayVideoSmall($row['type_of_player'],$row['the_valueable_bits']);
				$markerArray['###VIDEOPLAYER_MINI###'] = $this-> displayVideoMini($row['type_of_player'],$row['the_valueable_bits']);
				$markerArray['###THUMBNAIL###'] = $this->pi_linkTP_keepPIvars(
					'<img width="200" height="150" src="'.$this->getThumbnail($row['type_of_player'],$row['the_valueable_bits'],3).'" alt="Indl�ser..." /> ',
						$linkConf, 0, 0,
						$this->conf['singlePid']);
				$markerArray['###THUMBNAIL_SMALL###'] = $this->pi_linkTP_keepPIvars(
					'<img width="62" height="50" src="'.$this->getThumbnail($row['type_of_player'],$row['the_valueable_bits'],3).'" alt="Indl�ser..." /> ',
						$linkConf, 0, 0,
						$this->conf['singlePid']);
				}

				$content[] = $this->cObj->substituteMarkerArray($template, $markerArray);
				$alt = ($alt + 1) % 2;
			}
			$content = preg_replace('|###.*?###|i', '', implode($content, ' ')); // Clear not filled markers
			return $content;
		}

		return  $error;
	}
}
      
if (defined('TYPO3_MODE') && $TYPO3_CONF_VARS[TYPO3_MODE]['XCLASS']['ext/videoconnection/pi1/class.tx_videoconnection_pi1.php'])	{														
		include_once($TYPO3_CONF_VARS[TYPO3_MODE]['XCLASS']['ext/videoconnection/pi1/class.tx_videoconnection_pi1.php']);
}

?>
