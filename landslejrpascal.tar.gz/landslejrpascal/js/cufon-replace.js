
Cufon.replace('span.boxtext', { fontFamily:'Swiss 721 light', hover: true})('.box a', { fontFamily:'Swiss 721 light', hover: true})('h3', { fontFamily:'Swiss 721 light', hover: true})('h1', { fontFamily:'Swiss 721 light', hover: true})('h2', { fontFamily:'Swiss 721 light', hover: true});


Cufon.replace('.block .more-link a, .column-center .post-links ul.links li a', { fontFamily:'Swiss 721', hover: true});



