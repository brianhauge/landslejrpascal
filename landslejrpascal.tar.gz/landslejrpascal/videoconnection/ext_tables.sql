#
# Table structure for table 'tx_videoconnection_videos_category_mm'
# 
#
CREATE TABLE tx_videoconnection_videos_category_mm (
  uid_local int(11) DEFAULT '0' NOT NULL,
  uid_foreign int(11) DEFAULT '0' NOT NULL,
  tablenames varchar(30) DEFAULT '' NOT NULL,
  sorting int(11) DEFAULT '0' NOT NULL,
  KEY uid_local (uid_local),
  KEY uid_foreign (uid_foreign)
);



#
# Table structure for table 'tx_videoconnection_videos'
#
CREATE TABLE tx_videoconnection_videos (
	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,
	tstamp int(11) DEFAULT '0' NOT NULL,
	crdate int(11) DEFAULT '0' NOT NULL,
	cruser_id int(11) DEFAULT '0' NOT NULL,
	deleted tinyint(4) DEFAULT '0' NOT NULL,
	hidden tinyint(4) DEFAULT '0' NOT NULL,
	url tinytext NOT NULL,
	title tinytext NOT NULL,
	description text NOT NULL,
	category int(11) DEFAULT '0' NOT NULL,
	times_played int(11) DEFAULT '0' NOT NULL,
	the_valueable_bits tinytext NOT NULL,
	type_of_player tinytext NOT NULL,
    owner int(11) NOT NULL,
    file1 varchar(200) DEFAULT NULL,
  	file2 varchar(200) DEFAULT NULL,
  	file3 varchar(200) DEFAULT NULL,
	PRIMARY KEY (uid),
	KEY parent (pid)
);



#
# Table structure for table 'tx_videoconnection_videos_categories'
#
CREATE TABLE tx_videoconnection_videos_categories (
	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,
	tstamp int(11) DEFAULT '0' NOT NULL,
	crdate int(11) DEFAULT '0' NOT NULL,
	cruser_id int(11) DEFAULT '0' NOT NULL,
	deleted tinyint(4) DEFAULT '0' NOT NULL,
	hidden tinyint(4) DEFAULT '0' NOT NULL,
	categoryName varchar(30) NULL,
	shortdescription text NULL,
	description text NULL,
	type varchar(30) DEFAULT '0' NOT NULL,
	PRIMARY KEY (uid)
);

