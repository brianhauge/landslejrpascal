<?php

if (!defined ('TYPO3_MODE')) 	die ('Access denied.');

$TCA['tx_videoconnection_videos'] = array(
	'ctrl' => $TCA['tx_videoconnection_videos']['ctrl'],
	'interface' => Array (
		'showRecordFieldList' => 'title,hidden,url,description,category,times_played,the_valueable_bits,type_of_player,file1,file2,file3',
		'maxDBListItems' => 60,
	),
	'feInterface' => $TCA['tx_videoconnection_videos']['feInterface'],
	'columns' => array(
		'hidden' => Array (		
			'exclude' => 1,
			'label' => 'LLL:EXT:lang/locallang_general.xml:LGL.hidden',
			'config' => Array (
				'type' => 'check',
				'default' => '0'
			)
		),
		'url' => Array (		
			'exclude' => 1,		
			'label' => 'LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.url',		
			'config' => Array (
				'type' => 'input',	
				'size' => '30',
			)
		),
		'title' => Array (		
			'exclude' => 1,		
			'label' => 'LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.title',		
			'config' => Array (
				'type' => 'input',	
				'size' => '30',
			)
		),
		'description' => Array (		
			'exclude' => 1,		
			'label' => 'LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.description',		
			'config' => Array (
				'type' => 'text',
				'cols' => '32',	
				'rows' => '5',
			)
		),
		'category' => Array (		
			'exclude' => 1,		
			'label' => 'LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.category',		
			'config' => Array (
				'type' => 'select',	
				'foreign_table' => 'tx_videoconnection_videos_categories',	
				'title' => 'categoryName',
				'default_sortby' => 'ORDER BY categoryName', 
			#	'foreign_table_where' => 'AND tx_videoconnetion_videos_categories.pid=###CURRENT_PID### ORDER BY tx_videoconnetion_videos_categories.uid',	
				'size' => 1,	
				'minitems' => 0,
				'maxitems' => 1,	
			)
		),
		'times_played' => Array (		
			'exclude' => 1,		
			'label' => 'LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.times_played',		
			'config' => Array (
				'type' => 'input',
				'size' => '4',
				'max' => '4',
				'eval' => 'int',
				'checkbox' => '0',
				'range' => Array (
					'upper' => '1000',
					'lower' => '10'
				),
				'default' => 0
			)
		),
		'the_valueable_bits' => Array (		
			'exclude' => 1,		
			'label' => 'LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.the_valueable_bits',		
			'config' => Array (
				'type' => 'input',	
				'size' => '30',
			)
		),
		'type_of_player' => Array (		
			'exclude' => 1,		
			'label' => 'LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.type_of_player',		
			'config' => Array (
				'type' => 'select',
				'items' => Array (
					Array('LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.type_of_player.I.0', '0'),
					Array('LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.type_of_player.I.1', '1'),
					Array('LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.type_of_player.I.2', '2'),
					Array('LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.type_of_player.I.3', '3'),
					Array('LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.type_of_player.I.4', '4'),
					Array('LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.type_of_player.I.5', '6'),
				),
				'size' => 1,	
				'maxitems' => 1,
			)
		),
		'file1' => Array (		
			'exclude' => 1,		
			'label' => 'LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.file1',		
			'config' => Array (
				'type' => 'input',	
				'size' => '30',
			)
		),
		'file2' => Array (		
			'exclude' => 1,		
			'label' => 'LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.file2',		
			'config' => Array (
				'type' => 'input',	
				'size' => '30',
			)
		),
		'file3' => Array (		
			'exclude' => 1,		
			'label' => 'LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.file3',		
			'config' => Array (
				'type' => 'input',	
				'size' => '30',
			)
		),
	),
	'types' => Array (
		'0' => Array('showitem' => 'hidden;;1;;1-1-1, url, title;;;;2-2-2, description;;;;3-3-3, category, times_played, the_valueable_bits, type_of_player,file1,file2,file3')
	),
	'palettes' => Array (
		'1' => Array('showitem' => '')
	)
);



$TCA['tx_videoconnection_videos_categories'] = array(
	'ctrl' => $TCA['tx_videoconnection_videos_categories']['ctrl'],
	'interface' => Array (
		'showRecordFieldList' => 'hidden,categoryName,type,shortdescription,description',
		'maxDBListItems' => 60,
	),
	'feInterface' => $TCA['tx_videoconnection_videos']['feInterface'],
	
	'columns' => array(
		'hidden' => Array (		
			'exclude' => 1,
			'label' => 'LLL:EXT:lang/locallang_general.xml:LGL.hidden',
			'config' => Array (
				'type' => 'check',
				'default' => '0'
			)
		),
	
		'categoryName' => Array (		
			'exclude' => 1,		
			'label' => 'LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.title',		
			'config' => Array (
				'type' => 'input',	
				'size' => '30',
			)
		),
		
		'shortdescription' => Array (		
			'exclude' => 1,		
			'label' => 'LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.shortdescription',		
			'config' => Array (
				'type' => 'input',	
				'size' => '30',
			)
		),
		
		'description' => Array (		
			'exclude' => 1,		
			'label' => 'LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.description',		
			'config' => Array (
				'type' => 'text',	
				'size' => '30',
			),
			'defaultExtras' => 'richtext[*]:rte_transform[flag=rte_enabled|mode=ts_images]'
		),
		
		'type' => Array (		
			'exclude' => 1,		
			'label' => 'LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.type',		
			'config' => Array (
				'type' => 'select',
				'items' => Array (
					Array('LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.type.I.0', 'video'),
					Array('LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.type.I.1', 'description'),
					Array('LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.type.I.2', 'pictures'),
					Array('LLL:EXT:videoconnection/locallang_db.xml:tx_videoconnection_videos.type.I.3', 'all'),
				),
				'size' => 1,	
				'maxitems' => 1,
			)
		),

	),
	'types' => Array (
		'0' => Array('showitem' => 'hidden;;1;;1-1-1, categoryName, type, shortdescription, description')
	),
	'palettes' => Array (
		'1' => Array('showitem' => '')
	)
);


?>