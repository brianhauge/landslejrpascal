<?php

########################################################################
# Extension Manager/Repository config file for ext "videoconnection".
#
# Auto generated 18-11-2010 21:10
#
# Manual updates:
# Only the data in the array - everything else is removed by next
# writing. "version" and "dependencies" must not be touched!
########################################################################

$EM_CONF[$_EXTKEY] = array(
	'title' => 'FDF video connection',
	'description' => 'Show videos and stuff',
	'category' => 'plugin',
	'author' => 'Frederik Mogensen, David Askirk',
	'author_email' => 'frede@server-1.dk, x1q@fdf.dk',
	'shy' => '',
	'dependencies' => '',
	'conflicts' => '',
	'priority' => '',
	'module' => 'mod1',
	'state' => 'alpha',
	'internal' => '',
	'uploadfolder' => 0,
	'createDirs' => '',
	'modify_tables' => '',
	'clearCacheOnLoad' => 0,
	'lockType' => '',
	'author_company' => '',
	'version' => '0.1.7',
	'constraints' => array(
		'depends' => array(
		),
		'conflicts' => array(
		),
		'suggests' => array(
		),
	),
	'_md5_values_when_last_written' => 'a:31:{s:9:"ChangeLog";s:4:"d923";s:10:"README.txt";s:4:"9fa9";s:12:"ext_icon.gif";s:4:"2ee6";s:17:"ext_localconf.php";s:4:"7d90";s:14:"ext_tables.php";s:4:"f5a0";s:14:"ext_tables.sql";s:4:"a9ae";s:15:"flexform_ds.xml";s:4:"c7ca";s:34:"icon_tx_videoconnection_videos.gif";s:4:"2ee6";s:13:"locallang.xml";s:4:"c4ef";s:16:"locallang_db.xml";s:4:"14e5";s:7:"tca.php";s:4:"9f43";s:19:"doc/wizard_form.dat";s:4:"0f58";s:20:"doc/wizard_form.html";s:4:"39fd";s:14:"mod1/clear.gif";s:4:"cc11";s:13:"mod1/conf.php";s:4:"8f75";s:14:"mod1/index.php";s:4:"8501";s:18:"mod1/locallang.xml";s:4:"ca51";s:22:"mod1/locallang_mod.xml";s:4:"018b";s:19:"mod1/moduleicon.gif";s:4:"2ee6";s:14:"pi1/ce_wiz.gif";s:4:"02b6";s:36:"pi1/class.tx_videoconnection_pi1.php";s:4:"404c";s:44:"pi1/class.tx_videoconnection_pi1_wizicon.php";s:4:"0780";s:13:"pi1/clear.gif";s:4:"cc11";s:17:"pi1/locallang.xml";s:4:"3ff1";s:24:"pi1/static/constants.txt";s:4:"e1ec";s:24:"pi1/static/editorcfg.txt";s:4:"a8e1";s:11:"res/pi1.css";s:4:"61b5";s:21:"res/pi1_template.html";s:4:"7e9f";s:20:"static/constants.txt";s:4:"792b";s:16:"static/setup.txt";s:4:"8902";s:14:"static/tca.php";s:4:"d41d";}',
	'suggests' => array(
	),
);

?>